function carregarUsuarios() {
    //Requisição AJAX

    var xhttp = new XMLHttpRequest();

    xhttp.open('GET', "");

    xhttp.onload = function() {

    }

    xhttp.send();
}