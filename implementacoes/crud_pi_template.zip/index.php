<?php

include_once(__DIR__ . "/app/util/config.php");

header("location: " . HOME_PAGE);